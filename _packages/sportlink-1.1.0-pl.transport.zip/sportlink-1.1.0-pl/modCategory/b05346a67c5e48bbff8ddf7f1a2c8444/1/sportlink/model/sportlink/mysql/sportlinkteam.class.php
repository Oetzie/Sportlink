<?php

/**
 * Sportlink
 *
 * Copyright 2019 by Oene Tjeerd de Bruin <modx@oetzie.nl>
 */

require_once dirname(__DIR__) . '/sportlinkteam.class.php';

class SportlinkTeam_mysql extends SportlinkTeam
{
}
