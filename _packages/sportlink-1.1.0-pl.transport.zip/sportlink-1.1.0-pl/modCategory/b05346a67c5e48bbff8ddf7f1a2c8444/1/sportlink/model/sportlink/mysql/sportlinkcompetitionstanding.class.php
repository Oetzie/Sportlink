<?php

/**
 * Sportlink
 *
 * Copyright 2019 by Oene Tjeerd de Bruin <modx@oetzie.nl>
 */

require_once dirname(__DIR__) . '/sportlinkcompetitionstanding.class.php';

class SportlinkCompetitionStanding_mysql extends SportlinkCompetitionStanding
{
}
