<?php

/**
 * Sportlink
 *
 * Copyright 2019 by Oene Tjeerd de Bruin <modx@oetzie.nl>
 */

require_once dirname(__DIR__) . '/sportlinkmatch.class.php';

class SportlinkMatch_mysql extends SportlinkMatch
{
}
