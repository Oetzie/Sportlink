<?php

/**
 * Sportlink
 *
 * Copyright 2019 by Oene Tjeerd de Bruin <modx@oetzie.nl>
 */

require_once dirname(__DIR__) . '/sportlinkcompetition.class.php';

class SportlinkCompetition_mysql extends SportlinkCompetition
{
}
